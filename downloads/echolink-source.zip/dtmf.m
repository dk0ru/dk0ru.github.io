function dtmf
  rate = 44100;

  function y = d(length, char)
        time = 0:1/rate:length;
        switch char
            case {'1', '2', '3', 'A'}
                y = sin(2*pi*697*time);
            case {'4', '5', '6', 'B'}
                y = sin(2*pi*770*time); 
            case {'7', '8', '9', 'C'}
                y = sin(2*pi*852*time);
            case {'*', '0', '#', 'D'}
                y = sin(2*pi*941*time);
        end
        switch char
            case {'1', '4', '7', '*'}
                y = y + sin(2*pi*1209*time);
            case {'2', '5', '8', '0'}
                y = y + sin(2*pi*1336*time);
            case {'3', '6', '9', '#'}
                y = y + sin(2*pi*1477*time);
            case {'A', 'B', 'C', 'D'}
                y = y + sin(2*pi*1633*time);
        end
    end

    function y = silence(length)
        y = zeros(1, rate*length);
    end
  
    l = 0.4;
    s = silence(l);
    
    % 329356
    % w = [s d(l,'3') d(l,'2') s d(l,'9') s d(l,'3') s d(l,'5') s d(l,'6') s];
    
    % 31 53 20 42 21 31
    w = [s d(l, '3') s d(l, '1') s d(l, '5') s d(l, '3') s d(l, '2') s d(l, '0') s d(l, '4') s d(l, '2') s d(l, '2') s d(l, '1') s d(l, '3') s d(l, '1')];
    
    wavwrite(w,rate,'dtmf.wav');
end